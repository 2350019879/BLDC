extern void ADC_Init(void);
extern void GetAnalogWerte(void);
extern void AdConvert(void);
extern void FastADConvert(void);
